# Basit Link Sayfası (Link-in-bio) — Hazır Paket

Bu paket **tamamen ücretsiz** olarak GitHub Pages veya Vercel'e yükleyip kullanabileceğin basit bir `link-in-bio` (link sayfası) şablonudur.

İçindekiler:
- `index.html` — Ana sayfa (JS ile `links.json`'ı okur).
- `styles.css` — Stil dosyası.
- `links.json` — Linkleri buraya ekle (kolay düzenleme).
- `avatar.svg` — Yer tutucu avatar. Kendi resmiyle değiştir.
- `README.md` — Bu dosya.

## Hızlı kullanım (kod bilmeden) — GitHub Web UI ile
1. GitHub hesabı aç (https://github.com) veya varsa giriş yap.
2. Yeni repository oluştur: Repository adı olarak **`kullaniciadi.github.io`** yaz (örnek: `mehmet.github.io`). Bu, sitenin ana URL'si olur. Daha fazla bilgi: https://docs.github.com/en/pages/quickstart
3. Repo oluşturulduktan sonra `Add file` → `Upload files` ile bu paketteki dosyaları yükle ve Commit yap.
4. GitHub Pages otomatik olarak yayınlar ve site `https://kullaniciadi.github.io` adresinde görünür. (Yayınlama ayarları için repo -> Settings -> Pages bakabilirsiniz.)

## Vercel ile deploy (isteğe bağlı, daha gelişmiş)
1. Vercel hesabı aç (https://vercel.com) ve GitHub hesabını bağla.
2. New Project → GitHub repo'nu seç → Import et. Vercel, her commit'te otomatik deploy yapar. Rehber: https://vercel.com/docs/git/vercel-for-github

## Linkleri düzenleme (en kolay yol)
- GitHub repo'na gir → `links.json` dosyasını tıkla → `Edit` ile link ekle/çıkar → Commit.
- Örnek `links.json` formatı:
```json
[
  {"title":"Site 1","url":"https://example.com"},
  {"title":"YouTube","url":"https://youtube.com/kanal"}
]
```

## Özelleştirme önerileri
- `index.html` içindeki `<h1>` ve `<p>` etiketlerini düzenleyerek isim ve açıklamayı değiştir.
- `styles.css`'i değiştirerek renk ve yazı tiplerini güncelle.
- `avatar.svg`'yi `avatar.png` ile değiştir (GitHub'a yükle ve `index.html`'deki `src`'yi değiştir).

## Sorun çıkarsa
- `links.json` bozuk JSON ise site çalışmaz — dikkatli düzenle.
- GitHub Pages'de sayfa görünmüyorsa repo adının `kullaniciadi.github.io` olduğundan veya Pages ayarlarından `main`/`gh-pages` branch'inin seçili olduğundan emin ol.

İstersen ben şimdi bu dosyaları hazır hazırladım, sen bu zip'i alıp GitHub'a yükleyebilirsin — ya da istersen adım adım ekran görüntülü anlatırım. Kolay gelsin!